package com.example.leftoverapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    Button giveBtn;
    Button eatBtn;
    DocumentReference db = FirebaseFirestore.getInstance().document("Feed/City");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        CollectionReference cities = db.collection("cities");

        giveBtn = (Button) findViewById(R.id.give);
        giveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                moveToGiveFood();
            }
        });

        eatBtn = (Button) findViewById(R.id.Eat);
        eatBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToEatFood();
            }
        });

    }
    private void moveToGiveFood(){
        Intent intent = new Intent(MainActivity.this, GiveFood.class);
        startActivity(intent);
    }
    private void moveToEatFood(){
        Intent intent = new Intent(MainActivity.this, EatFood.class);
        startActivity(intent);
    }
}