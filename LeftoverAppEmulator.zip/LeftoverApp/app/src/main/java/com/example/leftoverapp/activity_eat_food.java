package com.example.leftoverapp;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;

public class activity_eat_food extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eat_food);
    }
}
