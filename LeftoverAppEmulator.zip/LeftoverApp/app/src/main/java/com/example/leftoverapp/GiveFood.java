package com.example.leftoverapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.widget.EditText;
import android.widget.Button;

import android.view.View;

import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class GiveFood extends AppCompatActivity {

    String name, organization, location, ingredients, dish;
    int quantity;
    boolean claim;

    EditText nameInput;
    EditText organizationInput;
    EditText locationInput;
    EditText ingredientsInput;
    EditText quantityInput;
    EditText dishInput;
    EditText expirationInput;
    DocumentReference db = FirebaseFirestore.getInstance().document("Feed/City");
    Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_give_food);

        nameInput=findViewById(R.id.nameInput);
        dishInput=findViewById(R.id.dishInput);
        organizationInput=findViewById(R.id.organizationInput);
        locationInput=findViewById(R.id.locationInput);
        ingredientsInput=findViewById(R.id.ingredientsInput);
        quantityInput=findViewById(R.id.quantityInput);
        expirationInput=findViewById(R.id.expirationInput);

        submitButton=findViewById(R.id.submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final HashMap<String,Object> data1 = new HashMap<String,Object>();
                    data1.put("Dish", dishInput.getText().toString());
                    data1.put("Event", organizationInput.getText().toString());
                    data1.put("User", ingredientsInput.getText().toString());
                    data1.put("Claimed", false);
                    data1.put("Quantity", ( Integer.valueOf(quantityInput.getText().toString())));
                    data1.put("Expiration", expirationInput.getText().toString());

                    db.collection("Feed/City").document(locationInput.getText().toString()).set(data1);
                }


            });
        };

}